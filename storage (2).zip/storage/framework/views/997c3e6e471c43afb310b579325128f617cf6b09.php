<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Contact Us Leads</title>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th><b>No</b></th>
                    <th><b>First Name</b></th>
                    <th><b>Last Name</b></th>
                    <th><b>Email</b></th>
                    <th><b>Phone #</b></th>             
                    <th><b>Message</b></th>
                    <th>Status</th>
                    <th><b>Date/Time</b></th>                   
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;

                ?>



                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $status = '';
                if($value->varStatus == 0)
                {
                    $status = "Pending";
                }elseif($value->varStatus == 1){
                    $status = "Completed";
                }else{
                    $status = "-";
                }

                 if($value->message != ''){
                $message = $value->message;
                }else
                {
                $message = 'N/A'; 
                }

                if($value->phone != ''){
                $phone = getDecryptedString($value->phone);
                }else
                {
                $phone = 'N/A'; 
                }

                ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($value->first_name); ?></td>
                    <td><?php echo e($value->last_name); ?></td>
                    <td><?php echo e(getDecryptedString($value->email)); ?></td>
                    <td><?php echo e($phone); ?></td> 
                    <td><?php echo e($message); ?></td>
                    <td><?php echo e($status); ?></td>
                    <td><?php echo e($value->created_at); ?></td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/contact_lead/export_excel.blade.php ENDPATH**/ ?>