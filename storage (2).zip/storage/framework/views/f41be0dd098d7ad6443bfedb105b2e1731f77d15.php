

<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap4.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="d-flex mb-4 justify-content-between">
                <h1 class="h3  text-gray-800">Inventory</h1>
                <a class="btn btn-primary float-right" href="<?php echo e(route('adminInventoryCreate')); ?>"> Add Inventory &nbsp;<i class="fas fa-solid fa-plus" style="font-size: 12px;"></i></a>
             </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($inventory->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr style="background:#eef2ffcf;">
                            <th data-orderable="true">No</th>
                            <th data-orderable="true">Name</th>
                            <th data-orderable="false">Other Detail</th>
                            <th data-orderable="true">Price</th>
                            <th data-orderable="false">Image</th>
                            <th data-orderable="false">Description</th>
                            <th data-orderable="flase">Status<span data-toggle="tooltip" data-placement="top" data-html="true" title="This Functionality helps you to publish/unpublish particular record.<br> So, if you don't want to show any record in front then you can unpublish that one."><i class="fa-solid fa-circle-question text-dark"></i></span></th>
                            <th data-orderable="false">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td width="15%">
                                    <a href="<?php echo e(route('adminInventoryEdit',base64_encode($inventory_data->id))); ?>"><?php echo e($inventory_data->name); ?></a>
                                    <span style="font-size: 13px;">
                                    <br><strong>Trim:</strong> <?php echo e($inventory_data->trim); ?>

                                    <br><strong>Model:</strong> <?php echo e($inventory_data->model); ?>

                                </span>
                                </td>
                                <td class="text-center">
                                    <a data-toggle="modal" class="btn btn-success" data-target="#other_detail_model<?php echo e($inventory_data->id); ?>"><i class="fas fa-solid fa-eye"></i></a>
                                    <!-- Modal -->
                                    <div id="other_detail_model<?php echo e($inventory_data->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"> Description of <strong class="text-dark"><?php echo e($inventory_data->name); ?></strong></h5>
                                                </div>
                                                <div class="modal-body text-left">
                                                <strong>Engine:</strong> <?php echo e($inventory_data->engine); ?> L
                                                <br><strong>transmission:</strong> <?php echo e($inventory_data->transmission == 'A'?'Automatic':'Manual'); ?>

                                                <br><strong>Exterior:</strong> <?php echo e($inventory_data->exterior_color); ?>

                                                <br><strong>Interior:</strong> <?php echo e($inventory_data->interior_color); ?>

                                                <br><strong>Transmission:</strong> <?php echo e($inventory_data->transmission_type == 'A'?'Automatic':'Manual'); ?>

                                                <br><strong>Km Driven:</strong> <?php echo e(number_format($inventory_data->km_driven)); ?> KM
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-secondary " data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                <span style="color:green; font-weight:600;">$ <?php echo e($inventory_data->full_price); ?></span>
                                <br>
                                <span style="font-size: 13px; color:purple;">
                                $ <?php echo e($inventory_data->biweekly_price); ?> Biwk (Tax Inc.)
                                <br>
                                <span style="color:orange; font-weight:600;"><?php echo e($inventory_data->biweekly_price_percentage); ?>%</span> for 
                                <span style="color:orange; font-weight:600;"><?php echo e($inventory_data->biweekly_installment_period); ?> Months</span>
                            </span>
                                </td>
                                <td width="5%" class="text-center">
                                    <?php
                                    $photo = asset('assets/img/default_image.jpg');
                                        if(isset($inventory_data->photo) && !empty($inventory_data->photo)){
                                            $photo = asset('assets/img/cars/'.$inventory_data->photo);
                                        }
                                    ?>
                                    <a href="<?php echo e($photo); ?>" class="fancybox" data-fancybox-group="gallery">
                                        <img src="<?php echo e($photo); ?>" height="40px" width="50px" class="rounded shadow-sm">
                                    </a>
                                    <br>
                                    
                                    <?php
                                        $inventory_gallery_count = \App\Models\inventory_gallery::where('parent_record_id',$inventory_data->id)->count();
                                    ?>
                                    <a style="font-size: 13px; margin-top: 50px;" href="<?php echo e(route('adminInventoryGallery',base64_encode($inventory_data->id))); ?>">Manage(<?php echo e($inventory_gallery_count); ?>)</a>
                                </td>
                                <td width="5%" class="text-center">
                                <a data-toggle="modal" class="btn btn-primary" data-target="#description_model<?php echo e($inventory_data->id); ?>"><i class="fas fa-solid fa-eye"></i></a>
                                <!-- Modal -->
                                <div id="description_model<?php echo e($inventory_data->id); ?>" class="modal fade" role="dialog">
                                    <div class="modal-dialog modal-lg">
                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"> Description of <strong class="text-dark"><?php echo e($inventory_data->name); ?></strong></h5>
                                            </div>
                                            <div class="modal-body text-left">
                                            <?php echo e($inventory_data->description); ?>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary " data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-center">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input publish_status" value="<?php echo e($inventory_data->is_active); ?>" url="<?php echo e(route('adminInventoryPublish')); ?>" rid="<?php echo e(base64_encode($inventory_data->id)); ?>" id="customSwitch<?php echo e(base64_encode($inventory_data->id)); ?>" <?php echo e($inventory_data->is_active == 1? "checked":""); ?>>
                                    <label class="custom-control-label" for="customSwitch<?php echo e(base64_encode($inventory_data->id)); ?>"></label>
                                </div>
                            </td>
                                <td>
                                    <a class="btn btn-success" href="<?php echo e(route('adminInventoryEdit',base64_encode($inventory_data->id))); ?>">Edit</a>
                                    <a class="btn btn-danger delete_record" rid="<?php echo e(base64_encode($inventory_data->id)); ?>"  href="<?php echo e(route('adminInventoryDelete',base64_encode($inventory_data->id))); ?>">Delete</a>
                                    <a href="<?php echo e(route('inventorydetail',['alias_name'=>$inventory_data->alias,'alias_id'=>$inventory_data->alias_id])); ?>" class="btn btn-info" target="_blank"><i class="fas fa-solid fa-location-arrow"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
            <?php else: ?>
            <div class="w-100 text-center">
                <h4>No Record Found!</h4>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    
$(document).ready(function() {
  $('#dataTable').DataTable();
});


$('.fancybox').fancybox({
  clickContent: 'close',
  buttons: ['close']
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/inventory/list.blade.php ENDPATH**/ ?>