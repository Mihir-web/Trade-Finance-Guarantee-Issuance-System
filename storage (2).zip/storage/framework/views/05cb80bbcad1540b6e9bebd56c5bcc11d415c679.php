

<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
<section class="banner-header section-padding bg-img" data-overlay-dark="8" data-background="<?php echo e(asset('assets/img/slider/11.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h6 class="wow slideInDown">What We Do</h6>
                        <h1 class="wow flipInX">Financing <span> Services</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- financing content -->
    <section class="my-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 px-lg-5 wow fadeInLeft">
                    <p class="cms-bold-heading">Buying a car, regardless of your credit situation is simple, fast,
                        professional and enjoyable at Guru Motors.</p>

                    <p>The process is simple: when you submit a form or give us a call, a member of our team is ready to
                        guide you through the process. We have a wide selection of cars from a number of brands to
                        choose from. We are passionate about providing an excellent experience for every client and
                        we're driven to get you driving- no matter your credit score or personal circumstances.</p>

                    <p>Our team of financing experts can help you, regardless of your credit:</p>

                    <ul class="cms-list mb-30">
                        <li>
                            Bad Credit
                        </li>
                        <li>
                            No Credit
                        </li>
                        <li>
                            New Credit
                        </li>
                        <li>
                            Divorce
                        </li>
                        <li>
                            Separation
                        </li>
                        <li>
                            Declined elsewhere
                        </li>
                        <li>
                            Credit Counseling
                        </li>
                        <li>
                            Self Employed
                        </li>
                        <li>
                            Collections
                        </li>
                        <li>
                            Missed Payments
                        </li>
                        <li>
                            R9's
                        </li>
                        <li>
                            Contractor
                        </li>
                        <li>
                            Disability
                        </li>
                        <li>
                            New Immigrant
                        </li>
                        <li>
                            Cash Income
                        </li>
                        <li>
                            Bankruptcy
                        </li>
                        <li>
                            Late Payments
                        </li>
                        <li>
                            Repossessions
                        </li>
                        <li>
                            Maternity
                        </li>
                        <li>
                            Proposal
                        </li>
                    </ul>
                    <p>If you have already been turned down, contact Guru Motors. We will get you driving!</p>
                </div>
                <!-- Form -->
                <div class="col-lg-6 col-md-12 mb-30 wow fadeInRight">
                    <div class="financing-form-box p-lg-5 py-5 px-1 text-center">
                        <div class="mb-5">
                        <span class="form-title">AUTO LOANS FOR ANY CREDIT SITUATION</span>
                        <p>GOOD CREDIT, BAD CREDIT, AND BANKRUPTCY</p>
                        <p>Hassle-free approvals in minutes. All credit is accepted. No SIN # is required.</p>
                    </div>
                        <form method="post" enctype="multipart/form-data" id="FinanceApplicationForm" action="<?php echo e(route('financing_application_store')); ?>">
                            <!-- form message -->
                            <!-- <div class="row">
                                <div class="col-12">
                                    <div class="alert alert-success contact__msg" style="display: none" role="alert">
                                        Your message was sent successfully. </div>
                                </div>
                            </div> -->
                            <!-- form elements -->
                            <div class="row">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-6 form-group">
                                    <input name="first_name" type="text" placeholder="Your First Name *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="last_name" type="text" placeholder="Your Last Name *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="email" type="email" placeholder="Your Email *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="phone" oninput="this.value = this.value.replace(/[^0-9]/g, '');" type="text" placeholder="Phone *" required>
                                    <br>
                                </div>
                                
                                <div class="col-md-12 form-group my-2">
                                    <div id="contactCaptcha" class="g-recaptcha"></div>
                                    <div class="capphitcha" data-sitekey="6LcIBdcpAAAAAK_phS_muy59mQUWrYblXk2leOU4">
                                        <?php if($errors->has('g-recaptcha-response')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('g-recaptcha-response')); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <label for="terms_and_condition">
                                    <input type="checkbox" name="terms_and_condition" id="terms_and_condition"> I Accept
                                    the terms and Conditions
                                    <br>
                                </label>
                                <div class="col-md-12 mt-3">
                                    <input name="submit" type="submit" value="Apply">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<!-- divider line -->
<div class="line-vr-section"></div>
    <!-- Booking Search -->
    <section class="background bg-img bg-fixed section-padding" data-overlay-dark="6"
        data-background="<?php echo e(asset('assets/img/slider/2.jpg')); ?>">
        <div class="container text-center">
            <h5 class="wow zoomIn">How Do You Get Approved?</h5>
            <span class="wow fadeInUp">Apply Now</span>
            <br>
            <span class="wow fadeInUp">It's simple! Call us or contact us through the form on this site and a qualified financing expert from
                our team will contact you promptly to guide you through the entire process.</span>
            <br>
            <br>
            <span class="wow fadeInUp">Select Your Vehicle</span>
            <br>
            <span class="wow fadeInUp">Whether you choose from our inventory or we source a vehicle for you, we are able to get you easy
                payments on a car you love.</span>
            <br>
            <br>
            <span class="wow fadeInUp">Drive Away</span>
            <br>
            <span class="wow fadeInUp">Congratulations! You are now part of the Guru Motors family! Share your experience with the people you
                love.</span>
            <br>
            <br>
            <h3 class="wow fadeInUp">We Have Relationships With Over <span style="color:#ed1c24;">25 Banks</span> To Get You Approved</h3>
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-01.png')); ?>" alt="td_bank_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-02.png')); ?>" alt="scotia_bank_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-03.png')); ?>" alt="cibc_bank_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-04.png')); ?>" alt="axis_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-05.png')); ?>" alt="eden_park" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-06.png')); ?>" alt="rifco_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-07.png')); ?>" alt="logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-08.png')); ?>" alt="carfincd_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-09.png')); ?>" alt="ia_finance_group_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-10.png')); ?>" alt="ggr_logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-11.png')); ?>" alt="logo" class="img-fluid banks-logo wow fadeInUp">
            <img src="<?php echo e(asset('assets/img/banks logo/logo-bank-12.png')); ?>" alt="ac_logo" class="img-fluid banks-logo wow fadeInUp">
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\StoreFinancingApplicationRequest','#FinanceApplicationForm'); ?>


<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script type="text/javascript">
    var sitekey = '6LfBPi0aAAAAAD61sTaFoHRf4Oe5ATqoIaWj96a0';
    var onloadCallback = function () {
        grecaptcha.render('contactCaptcha', {
            'sitekey': sitekey
        });
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/finance.blade.php ENDPATH**/ ?>