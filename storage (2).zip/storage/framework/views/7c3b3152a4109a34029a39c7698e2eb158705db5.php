<?php if(count($comments) > 0): ?>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="comments-wrap">
    <div class="comments-header">
        <div class="comment-by"><i class="fa fa-user-circle"></i><?php echo e($comment->user->name); ?></div>
        <div class="comment-time"><?php echo e($comment->created_at->diffForHumans()); ?></div>                                       
    </div>
    <div class="comments-content">
        <p><?php echo e($comment->comment); ?></p>
    </div> 
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="comments-wrap">
    <div class="comments-content mt-0">
        <p>There are no comments yet.</p>
    </div>
</div>
<?php endif; ?><?php /**PATH C:\wamp64\www\legislation-process-management\resources\views/commentlist.blade.php ENDPATH**/ ?>