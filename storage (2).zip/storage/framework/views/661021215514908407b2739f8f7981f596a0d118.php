<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Bills Report</title>
    </head>
    <body>
        <table>
            <thead>
                <tr>
                    <th><b>No</b></th>
                    <th><b>Title</b></th>
                    <th><b>Description</b></th>
                    <th><b>status</b></th>
                    <th><b>Author</b></th>             
                    <th><b>Date/Time</b></th>                   
                </tr>
            </thead>
            <tbody>
                <?php $i = 1;

                ?>



                <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $status = '';
                if($value->status == 1)
                {
                    $status = "Initial Draft";
                }elseif($value->status == 2){
                    $status = "Under review";
                }elseif($value->status == 3){
                    $status = "Approved";
                }elseif($value->status == 4){
                    $status = "Rejected";
                }elseif($value->status == 5){
                    $status = "Voting Ongoing";
                }else{
                    $status = "Passed";
                }

                 if($value->description != ''){
                $description = $value->description;
                }else
                {
                $description = 'N/A'; 
                }

               

                ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($value->title); ?></td>
                    
                  
                    <td><?php echo e($description); ?></td>
                    <td><?php echo e($status); ?></td>
                    <td><?php echo e($value->user->name); ?></td>
                    <td><?php echo e($value->created_at); ?></td>
                </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </body>
</html><?php /**PATH C:\wamp64\www\legislation-process-management\resources\views/bills/export_excel.blade.php ENDPATH**/ ?>