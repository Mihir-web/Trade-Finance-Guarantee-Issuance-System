

<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap4.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="card shadow mb-4">
<div class="card-body">
    <div class="d-flex justify-content-between my-4">
    <h2>Guarantees</h2>
    <div>
    <a href="<?php echo e(route('guaranteeCreate')); ?>" class="btn btn-primary">Create +</a>
    <a href="<?php echo e(route('guaranteeimportForm')); ?>" class="btn btn-primary">Import +</a>
    
    </div>
    </div>
    <div class="table-responsive">
    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>#</th>
                <th>Corporate Reference Number</th>
                <th>Guarantee Type</th>
                <th>Nominal Amount</th>
                <th>Expiry Date</th>
                <th>Applicant Name & Address</th>
                <th>Beneficiary Name & Address</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $guarantees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guarantee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($guarantee->corporate_reference_number); ?></td>
                <td><?php echo e($guarantee->guarantee_type); ?></td>
                <td><?php echo e($guarantee->nominal_amount_currency); ?> <?php echo e($guarantee->nominal_amount); ?></td>
               
                <td><?php echo e($guarantee->expiry_date); ?></td>
                <td><strong>Name:</strong> <?php echo e($guarantee->applicant_name); ?><br><strong>Address:</strong> <?php echo e($guarantee->applicant_address); ?></td>
                <td><strong>Name:</strong><?php echo e($guarantee->beneficiary_name); ?><br><strong>Address:</strong> <?php echo e($guarantee->beneficiary_name); ?></td>
                <td>
                    <select class="form-control form_input publish_status" name="status" url="<?php echo e(route('guaranteeStatusChange')); ?>" rid="<?php echo e(base64_encode($guarantee->corporate_reference_number)); ?>">
                                        <option value="1" <?php echo e($guarantee->status == 1? "selected":""); ?> >Draft</option>
                                        <option value="2" <?php echo e($guarantee->status == 2? "selected":""); ?> >Under Review</option>
                                        <option value="3" <?php echo e($guarantee->status == 3? "selected":""); ?> >Approved</option>
                                        <option value="4" <?php echo e($guarantee->status == 4? "selected":""); ?> >Rejected</option>
                                        <option value="5" <?php echo e($guarantee->status == 5? "selected":""); ?>>Issued</option>
                                        <option value="6" <?php echo e($guarantee->status == 6? "selected":""); ?>>Expired</option>
                                        <option value="7" <?php echo e($guarantee->status == 7? "selected":""); ?>>Revoked</option>
                                        <option value="8" <?php echo e($guarantee->status == 8? "selected":""); ?>>Cancelled</option>
                                    </select></td>
                <td>
                    <a href="<?php echo e(route('guaranteeEdit', $guarantee->corporate_reference_number)); ?>" class="btn btn-warning">Edit</a>
                    
                    <a class="btn btn-danger delete_record" rid="<?php echo e(base64_encode($guarantee->corporate_reference_number)); ?>"  href="<?php echo e(route('guaranteeDelete',base64_encode($guarantee->corporate_reference_number))); ?>">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
</div>
</div></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    
$(document).ready(function() {
  $('#dataTable').DataTable();
});


$('.fancybox').fancybox({
  clickContent: 'close',
  buttons: ['close']
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Trade-Finance-Guarantee-Issuance-System\resources\views/guarantees/list.blade.php ENDPATH**/ ?>