<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
<?php
    $segmantName = Request::segment(2);
    
    switch ($segmantName)
    {
    case "inventory":
        $page_title = "Inventory";
    break;
    case "testimonial":
        $page_title = "Testimonial";
    break;
    case "happy_clients":
        $page_title = "Happy clients";
    break;
    case "contactLeads":
        $page_title = "Contact Leads";
    break;
    case "financingLeads":
        $page_title = "Financing Leads";
    break;
    case "contact-info":
        $page_title = "Contact Info";
    break;
    default:
    $page_title = "Dashboard";
    break;
    }
?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Guru Motors">
    <meta name="robots" content="noindex, nofollow">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin Panel - <?php echo e($page_title); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('admin/assets/img/guru_motors_favicon.ico')); ?>" />
    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('admin/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('admin/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/jquery.fancybox.css')); ?>">
    <style>
        .error-help-block{
            color:red;
        }
        
    </style>
<?php echo $__env->yieldContent('internal_css'); ?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(Auth::user()->role_id == 1 ? route('adminInventory'): route('adminContactLeads')); ?>">
                <!-- <div class="sidebar-brand-icon rotate-n-15" style="color:#ed1c24;">
                    <i class="fas fa-laugh-wink"></i>
                </div> -->
                <img src="<?php echo e(asset('assets/img/logo-light.png')); ?>" class="img-fluid">
                <div class="sidebar-brand-text mx-3">Admin Panel</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">


            <!-- Nav Item - Dashboard -->
            <?php if(Auth::user()->role_id == 1): ?>
            <li class="nav-item <?php echo e($segmantName == 'inventory'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminInventory')); ?>">
                    <i class="fas fa-fw fa-car"></i>
                    <span>Inventory</span></a>
            </li>
            <?php endif; ?>

            <?php if(Auth::user()->role_id == 1): ?>
            <li class="nav-item <?php echo e($segmantName == 'testimonial'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminTestimonial')); ?>">
                    <i class="fas fa-solid fa-quote-right"></i>
                    <span>Testimonial</span></a>
            </li>
            <?php endif; ?>

            <?php if(Auth::user()->role_id == 1): ?>
            <li class="nav-item <?php echo e($segmantName == 'happy_clients'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminHappyClients')); ?>">
                <i class="fas fa-regular fa-laugh-wink"></i>
                    <span>Happy Clients</span></a>
            </li>
            <?php endif; ?>

            <li class="nav-item <?php echo e($segmantName == 'contactLeads'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminContactLeads')); ?>">
                    <i class="fas fa-fw fa-phone-alt"></i>
                    <span>Contacus leads</span></a>
            </li>

            <li class="nav-item <?php echo e($segmantName == 'financingLeads'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminFinancingLeads')); ?>">
                <i class="fas fa-solid fa-coins"></i>
                    <span>Financing leads</span></a>
            </li>

            <li class="nav-item <?php echo e($segmantName == 'contact-info'?'active':''); ?>">
                <a class="nav-link" href="<?php echo e(route('adminContactInfo')); ?>">
                <i class="fas fas-regular fa-address-book"></i>
                    <span>Contact Info</span></a>
            </li>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                            <a class="nav-link" target="_blank" href="<?php echo e(route('homepage')); ?>">
                                Visit Site &nbsp;<i class="fas fa-solid fa-location-arrow"></i>
                            </a>
                    </li>
                        <!-- Nav Item - Alerts -->
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(Auth::user()->name); ?></span>
                                <img class="img-profile rounded-circle"
                                    src="<?php echo e(asset('admin/assets/img/undraw_profile.svg')); ?>">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid m-0 p-0">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; AdminPanel 2024</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('admin/assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('admin/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('admin/assets/js/sb-admin-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/jquery.fancybox.js')); ?>"></script>
    <script src= "<?php echo e(asset('admin/assets/js/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/custom.js')); ?>"></script>
    
    
  <?php echo $__env->yieldContent('script'); ?>
  
</body>

</html><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>