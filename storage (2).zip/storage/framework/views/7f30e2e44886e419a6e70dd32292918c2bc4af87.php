

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Import Guarantees</h2>
    <form action="<?php echo e(route('guaranteeimport')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="file">Select File</label>
            <input type="file" name="file" id="file" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Import</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\Trade-Finance-Guarantee-Issuance-System\resources\views/guarantees/import.blade.php ENDPATH**/ ?>