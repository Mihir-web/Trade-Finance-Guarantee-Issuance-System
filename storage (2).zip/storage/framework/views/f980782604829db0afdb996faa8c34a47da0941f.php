<?php if($paginator->hasPages()): ?>

<!-- Pagination -->
            
                
                <p class="text-sm text-gray-700 leading-5">
                    <?php echo __('Showing'); ?>

                    <?php if($paginator->firstItem()): ?>
                        <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                        <?php echo __('to'); ?>

                        <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                    <?php else: ?>
                        <?php echo e($paginator->count()); ?>

                    <?php endif; ?>
                    <?php echo __('of'); ?>

                    <span class="font-medium"><?php echo e($paginator->total()); ?></span>
                    <?php echo __('results'); ?>

                </p>
            
<?php endif; ?>
<?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/vendor/pagination/custom_page_showing.blade.php ENDPATH**/ ?>