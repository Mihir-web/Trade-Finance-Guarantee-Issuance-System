


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Add Inventory</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>

                        <form class="user" id="inventoryCreate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('adminInventoryStore')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 ">
                                    <label for="name" class="text-dark">Name <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control form_input" id="name" placeholder="Name">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="model_year" class="text-dark">Select Model Year <span class="text-danger">*</span></label>
                                    <select class="form-control form_input" name="model">
                                        <option selected disabled value="">Select Model Year</option>
                                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <option value="<?php echo e($year->year); ?>"><?php echo e($year->year); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                      
                                    </select>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="car_type" class="text-dark">Select Car Type <span class="text-danger">*</span></label>
                                    <select class="form-control form_input" name="car_type">
                                        <option selected disabled value="">Select Car Type</option>
                                        <option value="Convertible">Convertible</option>
                                        <option value="Coupe">Coupe</option>
                                        <option value="Hatchback">Hatchback</option>
                                        <option value="Minivan">Minivan</option>
                                        <option value="Pickup Truck">Pickup Truck</option>
                                        <option value="Sedan">Sedan</option>
                                        <option value="Sports Car">Sports Car</option>
                                        <option value="Station Wagon">Station Wagon</option>
                                        <option value="SUV">SUV</option>
                                        <option value="Van">Van</option>
                                    </select>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="brand" class="text-dark">Select Brand <span class="text-danger">*</span></label>
                                    <select class="form-control form_input" name="brand">
                                        <option selected disabled value="">Select Brand</option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                      
                                    </select>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="trim" class="text-dark">Trim <span class="text-danger">*</span></label>
                                    <input type="text" name="trim" class="form-control form_input" id="trim" placeholder="Trim">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="engine" class="text-dark">Engine (L)<span class="text-danger">*</span></label>
                                    <input type="text" name="engine" class="form-control form_input" id="engine" placeholder="Engine">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="exterior_color" class="text-dark">Exterior Color <span class="text-danger">*</span></label>
                                    <input type="text" name="exterior_color" class="form-control form_input" id="exterior_color" placeholder="Exterior Color">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="interior_color" class="text-dark">Interior Color <span class="text-danger">*</span></label>
                                    <input type="text" name="interior_color" class="form-control form_input" id="interior_color" placeholder="Interior Color">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="km_driven" class="text-dark">KM Driven <span class="text-danger">*</span></label>
                                    <input type="text" name="km_driven" class="form-control form_input" id="km_driven" oninput="this.value = this.value.replace(/\D/g, '')" placeholder="KM Driven">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="transmission_type" class="text-dark">Select Transmission Type <span class="text-danger">*</span></label>
                                    <select class="form-control form_input" name="transmission_type">
                                        <option selected disabled value="">Select Transmission Type</option>
                                        <option value='A'>Automatic</option>
                                        <option value='M'>Manual</option>                                        
                                    </select>
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="full_price" class="text-dark">Full Price <span class="text-danger">*</span></label>
                                    <input type="text" name="full_price" class="form-control form_input" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); if(this.value.includes('.')) { let parts = this.value.split('.'); parts[1] = parts[1].substring(0, 2); this.value = parts.join('.'); }" id="full_price" placeholder="Full Price">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="biweekly_price" class="text-dark">Biweekly Price <span class="text-danger">*</span></label>
                                    <input type="text" name="biweekly_price" class="form-control form_input" id="biweekly_price" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); if(this.value.includes('.')) { let parts = this.value.split('.'); parts[1] = parts[1].substring(0, 2); this.value = parts.join('.'); }" placeholder="Biweekly Price">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="biweekly_price_percentage" class="text-dark">Biweekly Price Percentage <span class="text-danger">*</span></label>
                                    <input type="text" name="biweekly_price_percentage" class="form-control form_input" id="biweekly_price_percentage" oninput="this.value = this.value.replace(/[^0-9.]/g, ''); if(this.value.includes('.')) { let parts = this.value.split('.'); parts[1] = parts[1].substring(0, 2); this.value = parts.join('.'); }" placeholder="Biweekly Price Percentage">
                                </div>
                                <div class="col-sm-12 mb-3">
                                    <label for="biweekly_installment_period" class="text-dark">Biweekly Installment Period <span class="text-danger">*</span></label>
                                    <input type="text" name="biweekly_installment_period" class="form-control form_input" id="biweekly_installment_period" placeholder="Biweekly Installment Period">
                                </div>
                            </div>
                                <div class="form-group">
                                    <label for="name" class="text-dark">Description <span class="text-danger">*</span></label>
                                    <textarea class="w-100 text-area form_input" id="html-content" cols="42" rows="8" oninput="updateViewer()" name="description" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Description"></textarea>
                                </div>
                                Description Preview
                                <iframe id="html-viewer" frameborder="0" width="100%" height="300px" style="border:1px solid gray;border-radius: 12px;"></iframe>
                                <div class="form-check">
                                    <label class="form-check-label">
                                        <input type="checkbox" class="form-check-input photo_upload_checkbox" name="want_to_upload_photo" value="0">Want to Upload the Photo?
                                    </label>
                                </div>
                                <div class="form-group row d-none photo_upload">
                                    <label for="photo" class="col-12 text-dark">
                                        Upload Photo <span class="text-danger">*</span>
                                        <div class="image_upload text-center p-2 form_input" style="height:auto; width:100%; border-radius:10px; border:dashed 2px #d1d3e2;">
                                            <img src="<?php echo e(asset('admin/assets/img/upload_image.png')); ?>" height="100px" width="150px" class="preview_image rounded"/>
                                            <input type="file" name="photo" id="photo" style="width:1px; height:1px; visibility: hidden;" accept="image/*"/>
                                            <p class="text-secondary">Only JPG, and JPEG files are allowed, and file should not exceed size of 5mb.</p>
                                        </div>
                                    </label>
                                </div>
                                <hr>
                                <div class="form-group row">
                                    <div class="col-sm-12 mb-3">
                                        <label for="meta_title" class="text-dark">Meta Title<span class="text-danger">*</span></label>
                                        <input type="text" name="meta_title" class="form-control form_input" id="meta_title" placeholder="Meta Title" maxlength="50">
                                    </div>
                                    <div class="form-group col-sm-12">
                                        <label for="meta_description" class="text-dark">Meta Description <span class="text-danger">*</span></label>
                                        <textarea class="w-100 text-area form_input" cols="42" rows="8" maxlength="160" name="meta_description" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Meta Description"></textarea>
                                    </div>
                                </div>  
                                <div class="float-right mb-4">
                                    <a href="<?php echo e(route('adminInventory')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                        <i class="fa-solid fa-xmark"></i> Cancel
                                    </a>
                                    <button name="add_product" type="submit" value="1" class="btn btn-success btn-user">
                                        <i class="fa-solid fa-up-right-from-square"></i> Submit
                                    </button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\Admin\AddInventoryRequest','#inventoryCreate'); ?>

<script>
$('input[name=photo]').on('change', function(){
        changeImage(this);
    })
    function changeImage(input) {
  var reader;

  if (input.files && input.files[0]) {
    reader = new FileReader();

    reader.onload = function(e) {
      $('.preview_image').attr('src', e.target.result);
    }
    reader.readAsDataURL(input.files[0]);
  }
}

        function updateViewer() {
            // Get the HTML content from the textarea
            let htmlContent = document.getElementById('html-content').value;
            
            let final_content_tobe_loaded = `<html>
                                        <head>
                                        <link rel="stylesheet" href="<?php echo e(asset('assets/css/stlye.css')); ?>"/>
                                        <link rel="stylesheet" href="<?php echo e(asset('assets/css/cms.css')); ?>"/>
                                        </head>
                                        <body>
                                  `+htmlContent+`      
                                        </body>
                                        </html>`;
            // Get the iframe element
            let viewer = document.getElementById('html-viewer');

            // Write the HTML content to the iframe
            viewer.contentWindow.document.open();
            viewer.contentWindow.document.write(final_content_tobe_loaded);
            viewer.contentWindow.document.close();
        }

        $('.photo_upload_checkbox').on('change', function(){
            $('.photo_upload').toggleClass('d-none');
            $('.preview_image').attr('src',`<?php echo e(asset('admin/assets/img/upload_image.png')); ?>`);
            $('input[nme=photo]').val('');
            if($(this).is(':checked')){
            $('input[name=want_to_upload_photo]').val(1);
        }else{
            $('input[name=want_to_upload_photo]').val(0);
        }
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/inventory/create.blade.php ENDPATH**/ ?>