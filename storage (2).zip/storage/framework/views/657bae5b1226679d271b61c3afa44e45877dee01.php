

<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap4.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="d-flex mb-4 justify-content-between">
                <h1 class="h3  text-gray-800">Happy Clients</h1>
                <a class="btn btn-primary float-right" href="<?php echo e(route('adminHappyClientsCreate')); ?>"> Add Happy Client &nbsp;<i class="fas fa-solid fa-plus" style="font-size: 12px;"></i></a>
             </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($happy_clients->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr style="background:#eef2ffcf;">
                            <th data-orderable="true">No</th>
                            <th data-orderable="false">Image</th>
                            <th data-orderable="false">Message</th>
                            <th data-orderable="true">Display Order</th>
                            <th data-orderable="flase">Status<span data-toggle="tooltip" data-placement="top" data-html="true" title="This Functionality helps you to publish/unpublish particular record.<br> So, if you don't want to show any record in front then you can unpublish that one."><i class="fa-solid fa-circle-question text-dark"></i></span></th>
                            <th data-orderable="false">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $happy_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $happy_clients_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td width="5%" class="text-center">
                                    <?php
                                    $photo = asset('assets/img/default_image.jpg');
                                        if(isset($happy_clients_data->photo) && !empty($happy_clients_data->photo)){
                                            $photo = asset('assets/img/happyClients/'.$happy_clients_data->photo);
                                        }
                                    ?>
                                    <a href="<?php echo e($photo); ?>" class="fancybox" data-fancybox-group="gallery">
                                        <img src="<?php echo e($photo); ?>"  class="rounded shadow-sm img-fluid">
                                    </a>
                                    
                                </td>
                                <td class="text-center">
                                    <a data-toggle="modal" class="btn btn-success" data-target="#other_detail_model<?php echo e($happy_clients_data->id); ?>"><i class="fas fa-solid fa-eye"></i></a>
                                    <!-- Modal -->
                                    <div id="other_detail_model<?php echo e($happy_clients_data->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"> Message from client <strong class="text-dark"><?php echo e($happy_clients_data->name); ?></strong></h5>
                                                </div>
                                                <div class="modal-body text-left">
                                                    <?php echo e($happy_clients_data->message); ?>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-secondary " data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">
                                        <?php echo e($happy_clients_data->display_order); ?>

                                </td>
                                <td class="text-center">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input publish_status" value="<?php echo e($happy_clients_data->is_active); ?>" url="<?php echo e(route('adminHappyClientsPublish')); ?>" rid="<?php echo e(base64_encode($happy_clients_data->id)); ?>" id="customSwitch<?php echo e(base64_encode($happy_clients_data->id)); ?>" <?php echo e($happy_clients_data->is_active == 1? "checked":""); ?>>
                                    <label class="custom-control-label" for="customSwitch<?php echo e(base64_encode($happy_clients_data->id)); ?>"></label>
                                </div>
                            </td>   
                                <td>
                                    <a class="btn btn-success" href="<?php echo e(route('adminHappyClientsEdit',base64_encode($happy_clients_data->id))); ?>">Edit</a>
                                    <a class="btn btn-danger delete_record" rid="<?php echo e(base64_encode($happy_clients_data->id)); ?>"  href="<?php echo e(route('adminHappyClientsDelete',base64_encode($happy_clients_data->id))); ?>">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
            <?php else: ?>
            <div class="w-100 text-center">
                <h4>No Record Found!</h4>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    
$(document).ready(function() {
  $('#dataTable').DataTable();
});


$('.fancybox').fancybox({
  clickContent: 'close',
  buttons: ['close']
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/admin/happy_clients/list.blade.php ENDPATH**/ ?>