

<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/assets/css/dataTables.bootstrap4.min.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="d-flex mb-4 justify-content-between">
                <h1 class="h3  text-gray-800">Bills</h1>
                <?php if(Auth::user()->role_id == 2): ?>
                    <a class="btn btn-primary float-right" href="<?php echo e(route('billCreate')); ?>"> Add Bills &nbsp;<i class="fas fa-solid fa-plus" style="font-size: 12px;"></i></a>
                <?php endif; ?>
                </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger" id="alert_msg">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <?php if($bills->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr style="background:#eef2ffcf;">
                            <th data-orderable="true">No</th>
                            <th data-orderable="true">Title</th>
                            <th data-orderable="false">Description</th>
                            
                            
                            <?php if(Auth::user()->role_id == 1 || Auth::user()->role_id == 2): ?>
                                <th data-orderable="false">Voting</th>
                            <?php endif; ?>
                            <?php if(Auth::user()->role_id > 1 ): ?>
                            <th data-orderable="false">Amandment</th>
                           <?php endif; ?>

                            <?php if(Auth::user()->role_id < 3): ?>
                            <th data-orderable="flase">Status<span data-toggle="tooltip" data-placement="top" data-html="true" title="This Functionality helps you to publish/unpublish particular record.<br> So, if you don't want to show any record in front then you can unpublish that one."><i class="fa-solid fa-circle-question text-dark"></i></span></th>
                            <?php if(Auth::user()->role_id == 2): ?>
                            <th data-orderable="false">Actions</th>
                            <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 0;
                        ?>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td width="15%">
                                <?php if(($bill_data->status == 1 || $bill_data->status == 2) && $bill_data->author_id == Auth::user()->id): ?> 
                                    <a href="<?php echo e(route('billEdit',base64_encode($bill_data->id))); ?>"><?php echo e($bill_data->title); ?></a>
                                <?php else: ?>
                                    <?php echo e($bill_data->title); ?>

                                <?php endif; ?>
                                </span>
                                </td>
                                <td class="text-center">
                                    <a data-toggle="modal" class="btn btn-success" data-target="#other_detail_model<?php echo e($bill_data->id); ?>"><i class="fas fa-solid fa-eye"></i></a>
                                    <!-- Modal -->
                                    <div id="other_detail_model<?php echo e($bill_data->id); ?>" class="modal fade" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"> Description of <strong class="text-dark"><?php echo e($bill_data->title); ?></strong></h5>
                                                </div>
                                                <div class="modal-body text-left">
                                                    <p>
                                                        <?php echo e($bill_data->description); ?>

                                                    </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-secondary " data-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                               
                                <?php if(Auth::user()->role_id == 2): ?>
                                <td>
                                
                            </td>
                            <?php endif; ?>
                            <td>
                                <?php if(Auth::user()->role_id == 2): ?>
                                    <input type="radio" name="vote<?php echo e($bill_data->id); ?>" value="accept" id="Abstaint<?php echo e($bill_data->id); ?>"> <label for="Abstaint<?php echo e($bill_data->id); ?>">Abstaint</label>
                                    <br>
                                    <input type="radio" name="vote<?php echo e($bill_data->id); ?>" value="Against" id="Against<?php echo e($bill_data->id); ?>"> <label for="Against<?php echo e($bill_data->id); ?>">Against</label>
                                <?php endif; ?>
                            </td>
                               
                                <?php if(Auth::user()->role_id < 3): ?>

                            <td class="text-center">

                            <?php if(Auth::user()->role_id == 2): ?>
                                <?php if(Auth::user()->id == $bill_data->author_id): ?>
                                    <select class="form-control form_input publish_status" name="status" url="<?php echo e(route('billStatusChange')); ?>" rid="<?php echo e(base64_encode($bill_data->id)); ?>" <?php if( $bill_data->status == 3 || $bill_data->status == 4 || $bill_data->status == 5): ?> disabled <?php endif; ?>>
                                        <option value="1" <?php echo e($bill_data->status == 1? "selected":""); ?>>Draft</option>
                                        <option value="2" <?php echo e($bill_data->status == 2? "selected":""); ?>>Under Review</option>
                                        <option value="3" <?php echo e($bill_data->status == 3? "selected":""); ?> disabled>Approved</option>
                                            <option value="4" <?php echo e($bill_data->status == 4? "selected":""); ?> disabled>Rejected</option>
                                            <option value="5" <?php echo e($bill_data->status == 5? "selected":""); ?> disabled>Voting</option>
                                        <option value="6" <?php echo e($bill_data->status == 6? "selected":""); ?>>Passed</option>
                                    </select>
                                <?php else: ?>
                                    <?php if($bill_data->status == 1): ?>
                                        Draft
                                    <?php elseif($bill_data->status == 2): ?>
                                        Under Review
                                    <?php elseif($bill_data->status == 3): ?>
                                        Approved
                                    <?php elseif($bill_data->status == 4): ?>
                                        Rejected
                                    <?php elseif($bill_data->status == 5): ?>
                                        Voting Ongoing
                                    <?php else: ?>
                                        Passed
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(Auth::user()->role_id == 1): ?>    
                            
                                <select class="form-control form_input publish_status" name="status" url="<?php echo e(route('billStatusChange')); ?>" rid="<?php echo e(base64_encode($bill_data->id)); ?>" <?php if( $bill_data->status != 6 && $bill_data->status != 5): ?> disabled <?php endif; ?>>
                                        <option value="1" <?php echo e($bill_data->status == 1? "selected":""); ?> disabled>Draft</option>
                                        <option value="2" <?php echo e($bill_data->status == 2? "selected":""); ?> disabled>Under Review</option>
                                        <option value="3" <?php echo e($bill_data->status == 3? "selected":""); ?> >Approved</option>
                                        <option value="4" <?php echo e($bill_data->status == 4? "selected":""); ?> >Rejected</option>
                                        <option value="5" <?php echo e($bill_data->status == 5? "selected":""); ?>>Voting</option>
                                        <option value="6" <?php echo e($bill_data->status == 6? "selected":""); ?>>Passed</option>
                                    </select>

                                </div>
                            <?php endif; ?>
                                   
                            </td>
                            <?php if(Auth::user()->role_id == 2): ?>
                                <td>
                                <?php if(($bill_data->status == 1 || $bill_data->status == 2) && $bill_data->author_id == Auth::user()->id): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('billEdit',base64_encode($bill_data->id))); ?>">Edit</a>
                                <?php endif; ?>    
                                <?php if($bill_data->author_id == Auth::user()->id): ?>
                                    <a class="btn btn-danger delete_record" rid="<?php echo e(base64_encode($bill_data->id)); ?>"  href="<?php echo e(route('billDelete',base64_encode($bill_data->id))); ?>">Delete</a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                                </td>
                            <?php endif; ?>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
            <?php else: ?>
            <div class="w-100 text-center">
                <h4>No Record Found!</h4>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('admin/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script>
    
$(document).ready(function() {
  $('#dataTable').DataTable();
});


$('.fancybox').fancybox({
  clickContent: 'close',
  buttons: ['close']
})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\legislation-process-management\resources\views/bills/list.blade.php ENDPATH**/ ?>