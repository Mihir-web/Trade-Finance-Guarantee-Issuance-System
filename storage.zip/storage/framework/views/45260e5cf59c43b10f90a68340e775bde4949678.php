<?php $__env->startSection('content'); ?>
    <!-- Kenburns SlideShow -->
    <aside class="kenburns-section" id="kenburnsSliderContainer" data-overlay-dark="7">
        <div class="kenburns-inner h-100">
            <div class="v-middle caption">
                <div class="container">
                    <div class="row h-100">
                        <div class="col-md-12 text-center">
                            <h6 class="wow slideInDown">* Premium</h6>
                            <h1 class="wow zoomIn">GURU MOTORS</h1>
                            <h5 class="wow fadeInUp">The Best Dealership Of Certified Pre-Owned Vehicles</h5>
                            <a href="<?php echo e(route('inventorylist')); ?>" class="button-1 mt-15 mb-15 mr-15 wow fadeInLeft">View Our Inventory <span
                                    class="ti-arrow-top-right"></span></a>
                            <a href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us <span
                                    class="ti-arrow-top-right"></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </aside>
    
    <!-- About -->
    <section class="about section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 mb-30 wow fadeInLeft">
                    <div class="content">
                        <div class="section-subtitle">GURU MOTORS</div>
                        <div class="section-title">We Are More Than <span>A Car Dealership Company</span></div>
                        <p>If you are looking for an affordable vehicle, Guru Motors wants you to be confident about
                            your next
                            used car purchase. All of our quality <a href="<?php echo e(route('inventorylist')); ?>" class="cms-link">handpicked used
                                cars and minivans</a> are Certified and E-Tested, so you
                            know you are getting a safe and reliable vehicle.</p>
                        <p>Everyone's situation is different, but the good news is that having bad credit doesn't mean
                            you have to forget about having a car! Guru Motors is a trusted source in the GTA and
                            surrounding areas for helping people get approved for auto loans no matter what their
                            current credit situation is. When it comes to finding the right vehicle and getting a car
                            loan, we ensure the process for you is easy, secure, and stress-free. We handle your
                            financing while you choose your vehicle! Avoid sleepless nights and enjoy smooth driving! <a
                                href="<?php echo e(route('finance')); ?>" class="cms-link">Apply today!</a></p>
                        <a href="<?php echo e(route('aboutus')); ?>" class="button-4">Read More <span class="ti-arrow-top-right"></span></a>
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-1 col-md-12 wow fadeInRight">
                    <div class="item"> <img src="<?php echo e(asset('assets/img/about.jpg')); ?>" class="img-fluid" alt="about-us-image">
                        <div class="curv-butn icon-bg">
                            <a href="https://www.instagram.com/cars_by_guru/" class="vid">
                                <div class="icon"> <i class="ti-instagram"></i> </div>
                            </a>
                            <div class="br-left-top">
                                <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="w-11 h-11">
                                    <path
                                        d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                        fill="#fff"></path>
                                </svg>
                            </div>
                            <div class="br-right-bottom">
                                <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="w-11 h-11">
                                    <path
                                        d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                        fill="#fff"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if($inventory->count()>0): ?>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Cars 1 -->
    <section class="cars1 py-5" style="background:linear-gradient(#fffffff5,#fffffff5),url('<?php echo e(asset('assets/img/abstract-img.png')); ?>'); background-size:350px 350px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <!-- <div class="section-subtitle wow slideInDown">Select Your Car</div> -->
                    <div class="section-title wow flipInX">Select <span>Your Car</span></div>
                </div>
            </div>


            <div class="container cars2">
                <div class="car-list cars1-carousel owl-theme owl-carousel">
                    
                        <?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class=" wow fadeInUp">
                                <div class="item">
                                    <?php
                                        $photo = asset('assets/img/default_image.jpg');
                                        if(isset($inventory_data->photo) && !empty($inventory_data->photo)){
                                            $photo = asset('assets/img/cars/'.$inventory_data->photo);
                                        }
                                        
                                    ?>
                                    <figure><img src="<?php echo e($photo); ?>" alt="<?php echo e($inventory_data->photo ?? 'default-image'); ?>" class="img-fluid"></figure>
                                    <div class="content">
                                        <div class="cont">
                                            <h4 class="car_name"><?php echo e($inventory_data->name); ?> <span style="font-size: 14px;
                                                font-weight: 300;
                                                line-height: 1.95em;
                                                color: #555; margin-left:5px;"><?php echo e($inventory_data->trim); ?></span></h4>
                                            <div class="other_detail row mb-4 border-top border-bottom py-1">
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Model: </span> <?php echo e($inventory_data->model); ?></div>
                                                    <div><span class="car_listing_detail">Transmission: </span> <?php echo e($inventory_data->transmission_type == 'A'?'Auto':'Manual'); ?></div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Engine: </span> <?php echo e($inventory_data->engine); ?> L</div>
                                                    <div><span class="car_listing_detail">Km Driven: </span> <?php echo e(number_format($inventory_data->km_driven)); ?></div>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <div><span class="car_listing_detail">Exterior: </span> <?php echo e($inventory_data->exterior_color); ?>

                                                    </div>
                                                    <div><span class="car_listing_detail">Interior: </span> <?php echo e($inventory_data->interior_color); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="book">
                                                <div class="w-100 d-flex justify-content-between">
                                                    <div class="price">$<?php echo e(number_format($inventory_data->biweekly_price)); ?> <span>/ Biwk (Tax Inc.)</span>
                                                        <p><?php echo e(number_format($inventory_data->biweekly_price_percentage,2)); ?>% for <?php echo e(number_format($inventory_data->biweekly_installment_period)); ?> months</p>
                                                    </div>
                                                    <div class="price">$<?php echo e(number_format($inventory_data->full_price)); ?>

                                                    </div>
                                                </div> <a href="<?php echo e(route('inventorydetail',['alias_name'=> $inventory_data->alias, 'alias_id' =>  $inventory_data->alias_id])); ?>" class="button-5">View Detail</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
        </div>

    </section>
    <?php endif; ?>
    <?php if($happy_clients->count() > 0): ?>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <section class="team section-padding">
        <div class="container">
        <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle wow slideInDown">Pics With Our Clients</div>
                    <div class="section-title wow flipInX">Happy <span>Clients</span></div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                    <?php $__currentLoopData = $happy_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $happy_client_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item"> <img src="<?php echo e(asset('assets/img/HappyCLients/'.$happy_client_data['photo'])); ?>" class="img-fluid" alt="<?php echo e($happy_client_data['photo']); ?>">
                            <div class="bottom-fade"></div>
                            <div class="info">
                                <div class="butn icon-bg">
                                    <div class="vid">
                                        <div class="icon" style="display:flex; justify-content: center; align-items:center;">  <img src="<?php echo e(asset('assets/img/rating-stars.svg')); ?>" style="height:40px;width:40px;" class="svg_image"  alt="customer-rating-icon"> </div>
                                    </div>
                                    <div class="br-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-11 h-11">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#fff"></path>
                                        </svg>
                                    </div>
                                    <div class="br-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-11 h-11">
                                            <path d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z" fill="#fff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="title">
                                <h6><?php echo e($happy_client_data['message']); ?></h6>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    
    <?php if($testimonials->count()>0): ?>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Testimonials -->
    <section class="testimonials py-5 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle wow slideInDown">Testimonials</div>
                    <div class="section-title wow flipInX">What Clients Say</div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="stars"> <span class="rate">
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 1?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 2?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 3?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 4?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating == 5?'rated':''); ?>"></i>
                                </span>
                                <div class="shap-left-top">
                                    <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                        class="w-11 h-11">
                                        <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#fff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                        class="w-11 h-11">
                                        <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#fff"></path>
                                    </svg>
                                </div>
                            </div> <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p><?php echo e($testimonial_data->message); ?></p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"> 
                                        <?php if($testimonial_data->gender == 'M'): ?>
                                            <img src="<?php echo e(asset('assets/img/default-client-male.svg')); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/img/default-client-female.svg')); ?>" alt="">
                                        <?php endif; ?> 
                                         
                                    </div>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                            class="w-11 h-11">
                                            <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#fff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                            class="w-11 h-11">
                                            <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#fff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6><?php echo e($testimonial_data->client_first_name); ?></h6>
                                    <p><?php echo e($testimonial_data->client_last_name); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <div class="line-vr-section"></div>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="7" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Contact Us</h6>
                    <h5 class="wow flipInX">Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:"
                        class="button-1 mt-15 mb-15 mr-10 wow fadeInLeft"><i class="fa-brands fa-whatsapp"></i>
                        WhatsApp</a> <a href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us
                        <span class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/welcome.blade.php ENDPATH**/ ?>