
<?php $__env->startSection('internal_css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.fancybox.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.min.css')); ?>" />
 <link rel="stylesheet" href="<?php echo e(asset('assets/css/cms.css')); ?>" />
 <style>
    .detail-slider{
        background-color: #f2f2f2;
       padding: 20px;
       border-radius: 12px;
    }
    .detail-slider .detail-img_box .current_image{
        display: flex;
        height: 100% !important;
        background-color: white;
        padding: 10px 10px 0 10px;
        border-radius: 12px;
        justify-content: center;
        align-items: center;
        margin-bottom: 20px;
        width:100% !important;
    }

    .detail-slider .detail-img_box .current_image img{
       border-radius: 12px;
    }
    
  .detail-slider .rtl-slider {
    width:100% !important;
    height:100% !important;
  }

.detail-slider .rtl-slider-nav {
    display: flex;
    justify-content: center;
    align-items: center;
    place-content: center;
    width:90% !important;
    height:auto !important;
    margin: 0 20px;
    background-size: cover;
    background-position: center;
  }

  .detail-slider .rtl-slider-nav .rtl-slider-slide{
      padding: 0 10px;
  }

  .detail-slider .rtl-slider-nav .rtl-slider-slide img{
      border-radius: 8px;
      transition: all 0.25s ease-in-out;
  }

  .thumb-prev, .thumb-next{
    display: flex;
    justify-content: center;
    align-items: center;
    color:#ed1c24 !important;
  }

  .thumb-prev:hover{
    color:#000 !important;
  }

  .thumb-next:hover{
    color:#000 !important;
  }

  .detail-slider .rtl-slider-nav .rtl-slider-slide img:hover{
    border: 2px solid #ed1c24;
  }

  .back-to-listing{
    color:#fff;
  }
  .back-to-listing i{
    color:#ed1c24;
    margin-right: 10px;
    transition: all 0.25s ease-in-out;
  }
  .back-to-listing:hover i{
    margin-left: -10px;
  }


  .rtl-slider-slide a img{
    height:400px;
    width:auto;
  }

  @media  screen and (max-width: 991px) {
    .rtl-slider-slide a img{
    height:auto;
  }
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
    <section class="banner-header section-padding bg-img" data-overlay-dark="8" data-background="<?php echo e(asset('assets/img/slider/11.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="col-md-12 text-center">
                    <h6>Car Detail</h6>
                    <h1><?php echo e($car_data->name); ?>&nbsp;<span><?php echo e($car_data->model); ?>

                </span></h1>
                <div class="text-center back-to-listing">
                           
                <i class="fas fa-solid fa-arrow-left"></i>
                            <a href="<?php echo e(route('inventorylist')); ?>">
                                <div>Back to Listing</div>
                            </a>
                        </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Details -->
    <section class="car-details section-padding" style="padding: 30px 0;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <!--  Gallery Image -->
                    <div class="row">
                        <div class="col-md-12">
                            <h3>Image Gallery</h3>
                        </div>
                    </div>



                    <div class="col-12">
                    <?php if($car_photos->count() > 0): ?>
                        <div class="detail-slider">
                                <div class="detail-img_box">
                                    <div class="current_image">
                                    <div class="rtl-slider">
                                        <?php $__currentLoopData = $car_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car_photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="rtl-slider-slide">
                                            <a href="<?php echo e(asset('assets/img/cars/'.$car_photo->photo)); ?>" data-fancybox="gallery" style="height:100%; width: 100%; background-size:cover; background-position: center;display: flex; justify-content: center;">
                                                <img src="<?php echo e(asset('assets/img/cars/'.$car_photo->photo)); ?>" class="img-fluid" alt="<?php echo e($car_photo->photo); ?>">
                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                    <div style="display: flex; justify-content: center;">
                                    <span class="thumb-prev"><i class="fa-solid fa-chevron-left"></i></span>
                                    <div class="rtl-slider-nav">
                                        <?php $__currentLoopData = $car_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car_photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="rtl-slider-slide">
                                            <img src="<?php echo e(asset('assets/img/cars/'.$car_photo->photo)); ?>"  class="img-fluid" alt="">
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    
                                    <span class="thumb-next"><i class="fa-solid fa-chevron-right"></i><span>
                                    </div>
                                    
                                </div>
                            </div>
                    
                    <?php elseif(isset($car_data->photo) && !empty($car_data->photo)): ?>
                    <div class="gallery-container car-thumb d-flex justify-content-center wow fadeInLeft">
                        <div>
                            <a href="<?php echo e(asset('assets/img/cars/'.$car_data->photo)); ?>" class="fancybox" style="height:100%; width: 100%; background-size:cover; background-position: center;display: flex; justify-content: center;">
                            <img class="main-image img-fluid" src="<?php echo e(asset('assets/img/cars/'.$car_data->photo)); ?>" style="height:400px; width:auto; border-radius: 12px;" alt="Product Image">
                            </a>
                        </div>
                    </div>
                    <?php else: ?>
                    <img class="main-image img-fluid" src="<?php echo e(asset('assets/img/default_image.jpg')); ?>" style="height:500px; width:auto; border-radius: 12px;" alt="Product Image">
                    <?php endif; ?>
</div>
                </div>
                <!-- Sidebar -->
                <div class="col-lg-4 col-md-12 wow fadeInUp">
                    <div class="sidebar-car">
                        <div class="title d-flex justify-content-between">
                            <h4>$<?php echo e(number_format($car_data->full_price)); ?></h4>
                            <h4>/</h4>
                            <div>
                                <h4>$<?php echo e(number_format($car_data->biweekly_price)); ?> <span>/ Bi weekly</span></h4>
                                <h4><span><?php echo e(number_format($car_data->biweekly_price_percentage,2)); ?>% for <?php echo e(number_format($car_data->biweekly_installment_period)); ?> months</span></h4>
                            </div>

                        </div>
                        <div class="item">
                            <div class="features"><span><i class="fa-solid fa-car"></i> Model</span>
                                <p><?php echo e($car_data->model); ?></p>
                            </div>
                            <div class="features"><span><i class="fa-solid fa-hashtag"></i> Trim</span>
                                <p><?php echo e($car_data->trim); ?></p>
                            </div>
                            <div class="features"><span><i class="fa-solid fa-droplet"></i> Exterior Color</span>
                                <p><?php echo e($car_data->exterior_color); ?></p>
                            </div>
                            <div class="features"><span><i class="fa-solid fa-paint-roller"></i> Interior Color</span>
                                <p><?php echo e($car_data->interior_color); ?></p>
                            </div>
                            <div class="features"><span><i class="fa-regular fa-engine"></i> Engine</span>
                                <p><?php echo e($car_data->engine); ?>&nbsp;L</p>
                            </div>
                            <div class="features"><span><i class="omfi-transmission"></i> Transmission</span>
                                <p><?php echo e($car_data->transmission_type == 'A'?'Automatic':'Manual'); ?></p>
                            </div>
                            <div class="features"><span><i class="fa-solid fa-road"></i> Km Driven</span>
                                <p><?php echo e(number_format($car_data->km_driven)); ?>&nbsp;KM</p>
                            </div>
                            <div class="btn-double mt-30" data-grouptype="&amp;"> <a href="<?php echo e(route('contactus')); ?>">Contact Us</a> <a
                                    href="https://api.whatsapp.com/send?phone=8551004444" target="_blank"><span
                                        class="fa-brands fa-whatsapp"></span> WhatsApp</a> </div>
                        </div>
                    </div>
                </div>
            </div>
            
             <?php if(isset($car_data->description) && !empty($car_data->description)): ?>
                <div class="row my-5">
                   <h3>Description</h3>
                        <?php echo $car_data->description; ?>

                </div>
            <?php endif; ?> 
            
        </div>
    </section>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="5" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>Contact Us</h6>
                    <h5>Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:+6478966642"
                        class="button-1 mt-15 mb-15 mr-10 wow fadeInLeft"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a> <a
                        href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us <span
                            class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
<script>
     $(document).ready(function() {
    $('[data-fancybox="product-gallery"]').fancybox({
      thumbs : {
        autoStart : true
      }
    });

    $('.fancybox').fancybox({
        clickContent: 'close',
        buttons: ['zoom', 'slideShow', 'fullScreen', 'thumbs', 'close'],
      });
  });


$(document).ready(function() {
    $(".rtl-slider").slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: ".rtl-slider-nav"
    });
    $(".rtl-slider-nav").slick({
        slidesToShow: 7,
        slidesToScroll: 1,
        vertical: false,
        asNavFor: ".rtl-slider",
        centerMode: false,
        focusOnSelect: true,
        prevArrow: ".thumb-prev",
        nextArrow: ".thumb-next"
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/inventorydetail.blade.php ENDPATH**/ ?>