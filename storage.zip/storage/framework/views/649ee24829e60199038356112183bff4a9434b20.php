

<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
<section class="banner-header section-padding bg-img" data-overlay-dark="7" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h6 class="wow slideInDown">Guru Motors</h6>
                        <h1 class="wow fadeInUp">About <span>Us</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About -->
    <section class="about section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow fadeInLeft">
                    <div class="content">
                        <div class="section-subtitle">Guru Motors</div>
                        <div class="section-title">We Are More Than <span>A Car Dealership Company</span></div>
                        <p>If you are looking for an affordable vehicle, Guru Motors wants you to be confident about your next
                            used car purchase. All of our quality <a href="cars.html" class="cms-link">handpicked used cars and minivans</a> are Certified and E-Tested, so you
                            know you are getting a safe and reliable vehicle.</p>
                        <p>Everyone's situation is different, but the good news is that having bad credit doesn't mean you have to forget about having a car! Guru Motors is a trusted source in the GTA and surrounding areas for helping people get approved for auto loans no matter what their current credit situation is. When it comes to finding the right vehicle and getting a car loan, we ensure the process for you is easy, secure, and stress-free. We handle your financing while you choose your vehicle! Avoid sleepless nights and enjoy smooth driving! <a href="finance.html" class="cms-link">Apply today!</a></p>
                    </div>
                </div>
                <div class="col-md-5 offset-md-1 wow fadeInRight">
                    <div class="item">
                        <img src="<?php echo e(asset('assets/img/about.jpg')); ?>" class="img-fluid" alt="about-us-image">
                        <div class="curv-butn icon-bg">
                            <a href="https://www.instagram.com/cars_by_guru?igsh=MW9kMWduZ2puNm83NQ==" class="vid">
                                <div class="icon"> <i class="ti-instagram"></i> </div>
                            </a>
                            <div class="br-left-top">
                                <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="w-11 h-11">
                                    <path
                                        d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                        fill="#fff"></path>
                                </svg>
                            </div>
                            <div class="br-right-bottom">
                                <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                    class="w-11 h-11">
                                    <path
                                        d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                        fill="#fff"></path>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="item">
                        <p class="my-3">Guru Motors offers used vehicle financing through major lending institutions at the best financing rates and terms available. We can help you tailor your affordable used car loan to fit your budget and your lifestyle. A pre-approved car loan is short and simple. <a href="finance.html" class="cms-link">Complete our secure, easy, online financing application.</a> We will contact you promptly to discuss your vehicle financing options and provide the financing solution that works best for you.</p>
                        <p class="my-3">Guru Motors is an OMVIC licensed used car dealer, <a href="https://maps.app.goo.gl/UmWts8pb9Lv9hRcX8" class="cms-link">located at 1261 Kennedy Rd Unit A, in Toronto ON.</a></p>
                        <p class="my-3">OMVIC is responsible for administering Ontario's Motor Vehicle Dealers Act, to ensure a fair, safe and informed marketplace in Ontario by protecting the rights of consumers, enhancing industry professionalism and ensuring fair, honest and open competition for registered motor vehicle dealers.</p>
                        <p class="cms-bold-heading">We are also a UCDA member dealer. UCDA members voluntarily agree to a Code of Ethics urging them to:</p>
                        <ul class="list-unstyled list mb-30">
                            <li>
                                <div class="list-icon"> <span class="ti-check"></span> </div>
                                <div class="list-text">
                                    <p>Disclose everything they know about the vehicle</p>
                                </div>
                            </li>
                            <li>
                                <div class="list-icon"> <span class="ti-check"></span> </div>
                                <div class="list-text">
                                    <p>Present their vehicles fairly and accurately</p>
                                </div>
                            </li>
                            <li>
                                <div class="list-icon"> <span class="ti-check"></span> </div>
                                <div class="list-text">
                                    <p>Ensure that customers fully understand the products and services being offered</p>
                                </div>
                            </li>
                            <li>
                                <div class="list-icon"> <span class="ti-check"></span> </div>
                                <div class="list-text">
                                    <p>Deliver on all promises</p>
                                </div>
                            </li>
                            <li>
                                <div class="list-icon"> <span class="ti-check"></span> </div>
                                <div class="list-text">
                                    <p>Deal with reasonable complaints promptly</p>
                                </div>
                            </li>
                        </ul>
                        <p>Visit UCDA online at <a href="www.ucda.ca" class="cms-link">www.ucda.ca</a> or call toll-free: <a href="tel:18002682598" class="cms-link">1-800-268-2598</a></p>
                    </div>
                    <img src="<?php echo e(asset('assets/img/omvic.png')); ?>" class="w-25 img-fluid wow flipInX" alt="ontario's vehicle slaes regulator">
                    <img src="<?php echo e(asset('assets/img/ucda.png')); ?>" class="w-25 img-fluid wow flipInX" alt="ucda">
                </div>
            </div>
        </div>
    </section>
    
    <?php if($testimonials->count()>0): ?>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Testimonials -->
    <section class="testimonials py-5 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mb-30">
                    <div class="section-subtitle wow slideInDown">Testimonials</div>
                    <div class="section-title wow flipInX">What Clients Say</div>
                </div>
                <div class="col-md-12">
                    <div class="owl-carousel owl-theme">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="stars"> <span class="rate">
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 1?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 2?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 3?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating >= 4?'rated':''); ?>"></i>
                                    <i class="fa-solid fa-star <?php echo e($testimonial_data->rating == 5?'rated':''); ?>"></i>
                                </span>
                                <div class="shap-left-top">
                                    <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                        class="w-11 h-11">
                                        <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#fff"></path>
                                    </svg>
                                </div>
                                <div class="shap-right-bottom">
                                    <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                        class="w-11 h-11">
                                        <path
                                            d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                            fill="#fff"></path>
                                    </svg>
                                </div>
                            </div> <i class="fa-solid fa-quote-left"></i>
                            <div class="text">
                                <p><?php echo e($testimonial_data->message); ?></p>
                            </div>
                            <div class="info mt-30">
                                <div class="img-curv">
                                    <div class="img"> 
                                        <?php if($testimonial_data->gender == 'M'): ?>
                                            <img src="<?php echo e(asset('assets/img/default-client-male.svg')); ?>" alt="">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/img/default-client-female.svg')); ?>" alt="">
                                        <?php endif; ?> 
                                         
                                    </div>
                                    <div class="shap-left-top">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                            class="w-11 h-11">
                                            <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#fff"></path>
                                        </svg>
                                    </div>
                                    <div class="shap-right-bottom">
                                        <svg viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg"
                                            class="w-11 h-11">
                                            <path
                                                d="M11 1.54972e-06L0 0L2.38419e-07 11C1.65973e-07 4.92487 4.92487 1.62217e-06 11 1.54972e-06Z"
                                                fill="#fff"></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="ml-30">
                                    <h6><?php echo e($testimonial_data->client_first_name); ?></h6>
                                    <p><?php echo e($testimonial_data->client_last_name); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="7" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6 class="wow slideInDown">Contact Us</h6>
                    <h5 class="wow zoomIn">Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:+6478966642"
                        class="button-1 mt-15 mb-15 mr-10 wow fadeInLeft"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a> <a
                        href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15 wow fadeInRight">Contact Us <span
                            class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/aboutus.blade.php ENDPATH**/ ?>