

<?php $__env->startSection('internal_css'); ?>
<style>
.capphitcha .help-block{
    color:red !important;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Header Banner -->
<section class="banner-header middle-height section-padding bg-img" data-overlay-dark="8" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="v-middle">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h6 class="wow slideInDown">Get in touch</h6>
                        <h1 class="wow fadeInUp">Contact <span>Us</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Contact Box -->
    <div class="contact-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon omfi-envelope"></span>
                        <h5>Email us</h5>
                        <p>admin@gurumotors.com</p> <i class="numb omfi-envelope"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon omfi-location"></span>
                        <h5>Our address</h5>
                        <p>1261 Kennedy Rd S,Scarborough</p> <i class="numb omfi-location"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon ti-time"></span>
                        <h5>Opening Hours</h5>
                        <p>Mon-Sun: 8 AM - 7 PM</p> <i class="numb ti-time"></i>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 animate-box" data-animate-effect="fadeInUp">
                    <div class="item"> <span class="icon omfi-phone"></span>
                        <h5>Call us</h5>
                        <p>+1 647-896-6642</p> <i class="numb omfi-phone"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact -->
    <section class="contact section-padding">
        <div class="container">
            <div class="row">
                <!-- Form -->
                <div class="col-lg-6 col-md-12 mb-30 wow fadeInLeft">
                    <div class="form-box">
                        <h5>Get in touch</h5>
                        <form method="post" enctype="multipart/form-data" id="contactusForm" action="<?php echo e(route('contact_store')); ?>">
                          
                        <!-- form message -->
                            <!-- <div class="row">
                                <div class="col-12">
                                    <div class="alert alert-success contact__msg" style="display: none" role="alert"> Your message was sent successfully. </div>
                                </div>
                            </div> -->
                            <!-- form elements -->
                            <div class="row">
                            <?php echo csrf_field(); ?>  
                                <div class="col-md-6 form-group">
                                    <input name="first_name" type="text" placeholder="Your First Name *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="last_name" type="text" placeholder="Your Last Name *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="email" type="email" placeholder="Your Email *" required>
                                    <br>
                                </div>
                                <div class="col-md-6 form-group">
                                    <input name="phone" type="text" oninput="this.value = this.value.replace(/[^0-9]/g, '');" placeholder="Your Number *" required>
                                    <br>
                                </div>
                                <div class="col-md-12 form-group">
                                    <textarea name="message" id="message" cols="30" rows="4" placeholder="Message *" required></textarea>
                                    <br>
                                </div>
                                <div class="col-md-12 form-group mb-4">
                                    <div id="contactCaptcha" class="g-recaptcha"></div>
                                    <div class="capphitcha" data-sitekey="6LcIBdcpAAAAAK_phS_muy59mQUWrYblXk2leOU4">
                                        <?php if($errors->has('g-recaptcha-response')): ?>
                                        <span class="help-block">
                                            <?php echo e($errors->first('g-recaptcha-response')); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <input name="submit" type="submit" value="Send Message">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Map -->
                <div class="col-lg-5 offset-lg-1 col-md-12 wow fadeInRight">
                    <h5>Location</h5>
                    <div class="google-map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1440.8768933266122!2d-79.27706483063899!3d43.75720940129799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89d4d1ee4c6b6165%3A0xbbfd4c69b9c43802!2sFrontier%20Fine%20Cars!5e0!3m2!1sen!2sca!4v1712729554659!5m2!1sen!2sca" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- divider line -->
    <div class="line-vr-section"></div>
    <!-- Lets Talk -->
    <section class="lets-talk bg-img bg-fixed section-padding" data-overlay-dark="6" data-background="<?php echo e(asset('assets/img/slider/3.jpg')); ?>">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h6>Contact Us</h6>
                    <h5>Want to reach out to us?</h5>
                    <p>Don't hesitate and send us a message.</p> <a href="tel:+6478966642" class="button-1 mt-15 mb-15 mr-10"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a> <a href="<?php echo e(route('contactus')); ?>" class="button-2 mt-15 mb-15">Contact Us <span class="ti-arrow-top-right"></span></a>
                </div>
            </div>
        </div>
    </section>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\StoreContactRequest','#contactusForm'); ?>


<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script type="text/javascript">
    var sitekey = '6LfBPi0aAAAAAD61sTaFoHRf4Oe5ATqoIaWj96a0';
    var onloadCallback = function () {
        grecaptcha.render('contactCaptcha', {
            'sitekey': sitekey
        });
    };
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/contactus.blade.php ENDPATH**/ ?>