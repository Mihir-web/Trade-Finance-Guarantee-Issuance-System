


<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="p-lg-5 p-4">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Add Bill</h1>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('error')): ?>
                            <div class="alert alert-danger" id="alert_msg">
                                <p><?php echo e($message); ?></p>
                            </div>
                        <?php endif; ?>

                        <form class="user" id="billCreate" method="POST" enctype="multipart/form-data" action="<?php echo e(route('billStore')); ?>">
                        <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-sm-12 mb-3 ">
                                    <label for="name" class="text-dark">Title <span class="text-danger">*</span></label>
                                    <input type="text" name="title" class="form-control form_input" id="title" placeholder="Title">
                                </div>

                                <div class="col-sm-12 mb-3">
                                    <label for="name" class="text-dark">Description <span class="text-danger">*</span></label>
                                    <textarea class="w-100 text-area form_input" id="html-content" cols="42" rows="8" oninput="updateViewer()" name="description" style="border-radius:8px; border:1px solid #d1d3e2 !important;" placeholder="Description"></textarea>
                                </div>
                                
                                <div class="float-right mb-4">
                                    <a href="<?php echo e(route('bills')); ?>" class="btn btn-user btn-outline btn-outline-secondary">
                                        <i class="fa-solid fa-xmark"></i> Cancel
                                    </a>
                                    <button name="add_bill" type="submit" value="1" class="btn btn-success btn-user">
                                        <i class="fa-solid fa-up-right-from-square"></i> Submit
                                    </button>
                                </div>

                                <input type="hidden" name="author_id" value="<?php echo e(Auth::user()->id); ?>">
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('vendor/jsvalidation/js/jsvalidation.js')); ?>"></script>
<?php echo JsValidator::formRequest('App\Http\Requests\AddBillRequest','#billCreate'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\legislation-process-management\resources\views/bills/create.blade.php ENDPATH**/ ?>