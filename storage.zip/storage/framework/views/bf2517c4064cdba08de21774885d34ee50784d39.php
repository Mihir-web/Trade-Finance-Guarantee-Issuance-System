<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <?php if(isset($is_thankyou_page) && $is_thankyou_page == 1): ?>
    <meta name="robots" content="noindex, nofollow">
    <?php endif; ?>
    <title>
        <?php if(isset($meta_title) && !empty($meta_title)): ?>
    <?php echo e($meta_title); ?> | Guru Motors
    <?php else: ?>
    GuruMotors
    <?php endif; ?>
</title>
<?php if(isset($meta_title) && !empty($meta_title)): ?>
    <meta name="description" content="<?php echo e($meta_description); ?>">
    <?php endif; ?>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/guru_motors_favicon.ico')); ?>" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&amp;display=swap">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/plugins.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <?php echo $__env->yieldContent('internal_css'); ?>
</head>
<body>
    <?php
        $contact_info = App\Models\contact_info::where('id', 1)->first();
    ?>
    <!-- Preloader -->
    <div class="preloader-bg"></div>
    <div id="preloader">
        <div id="preloader-status">
            <div class="preloader-position loader"> <span></span> </div>
        </div>
    </div>
    <!-- Progress scroll totop -->
    <div class="progress-wrap cursor-pointer">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <!-- Logo -->
            <div class="logo-wrapper">
            <a class="logo" href="<?php echo e(route('homepage')); ?>"> <img src="<?php echo e(asset('assets/img/logo-light.png')); ?>" class="logo-img" alt="Guru Motors Logo"> </a>
            </div>
            <!-- Button -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar"
                aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation"> <span
                    class="navbar-toggler-icon"><i class="fa-solid fa-bars"></i></span> </button>
            <!-- Menu -->
            <?php
                $path =  request()->segment(count(request()->segments()));
            ?>
            <div class="collapse navbar-collapse" id="navbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"> <a class="nav-link <?php echo e((!isset($path) || empty($path))? 'active':''); ?>" href="<?php echo e(route('homepage')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e((isset($path) && !empty($path) && $path == 'about-us')? 'active':''); ?>" href="<?php echo e(route('aboutus')); ?>">About Us</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e((isset($path) && !empty($path) && $path == 'finance')? 'active':''); ?>" href="<?php echo e(route('finance')); ?>">Finance</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e((isset($path) && !empty($path) && ($path == 'inventory-list' || $path == 'inventory-detail'))? 'active':''); ?>" href="<?php echo e(route('inventorylist')); ?>">Inventory</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo e((isset($path) && !empty($path) && $path == 'contact-us')? 'active':''); ?>" href="<?php echo e(route('contactus')); ?>" href="<?php echo e(route('contactus')); ?>">Contact</a></li>
                </ul>
                <div class="navbar-right">
                    <div class="wrap">
                        <div class="icon"> <a href="tel:<?php echo e(str_replace('-','',$contact_info->phone_no)); ?>"><i class="flaticon-phone-call"></i></a> </div>
                        <div class="text">
                            <p>Need help?</p>
                            <h5><a href="tel:<?php echo e(str_replace('-','',$contact_info->phone_no)); ?>"><?php echo e($contact_info->phone_no); ?></a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    
    <?php echo $__env->yieldContent('content'); ?>
    
        <!-- Clients -->
    <section class="clients">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="owl-carousel owl-theme">
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/bmw_logo.png')); ?>" alt="bmw_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/audi_logo.png')); ?>" alt="audi_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/mercedes_logo.png')); ?>" alt="mercedes_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/volvo_logo.png')); ?>" alt="volvo_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/jeep_logo.png')); ?>" alt="jeep_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/subaru_logo.png')); ?>" alt="subaru_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/volkswagen_logo.png')); ?>" alt="volkswagen_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/hyundai_logo.png')); ?>" alt="hyundai_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/honda_logo.png')); ?>" alt="honda_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/lexus_logo.png')); ?>" alt="lexus_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/mitsubishi_logo.png')); ?>" alt="mitsubishi_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/nissan_logo.png')); ?>" alt="nissan_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/ford_logo.png')); ?>" alt="ford_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/toyota_logo.png')); ?>" alt="toyota_logo.png"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/dodge_logo.png')); ?>" alt="dodge_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/kia_logo.png')); ?>" alt="kia_logo"></a>
                        </div>
                        <div class="clients-logo">
                            <a href="#0"><img src="<?php echo e(asset('assets/img/clients/chrysler_logo.png')); ?>" alt="chrysler_logo"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>   
<!-- Footer -->
<footer class="footer clearfix">
        <div class="container">
            
            <!-- second footer -->
            <div class="second-footer">
                <div class="row">
                    <!-- about & social icons -->
                    <div class="col-md-4 widget-area">
                        <div class="widget clearfix">
                            <div class="footer-logo"><img src="<?php echo e(asset('assets/img/logo-light.png')); ?>" alt="Guru Motors Logo"></div>
                            <!-- <div class="footer-logo"><h2>CARE<span>X</span></h2></div> -->
                            <div class="widget-text">
                                <p>Cars that Speak Volumes, Deals that Speak Savings
                                </p>
                                <div class="social-icons">
                                    <ul class="list-inline">
                                        <a href="whatsapp://send?phone=<?php echo e(str_replace('-','',$contact_info->whatsapp_no)); ?>">
                                            <li><i class="fa-brands fa-whatsapp"></i></li>
                                        </a>
                                        <a href="<?php echo e($contact_info->facebook); ?>">
                                            <li><i class="fa-brands fa-facebook-f"></i></li>
                                        </a>
                                        <a href="<?php echo e($contact_info->instagram); ?>">
                                            <li><i class="fa-brands fa-instagram"></i></li>
                                        </a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- quick links -->
                    <div class="col-md-3 offset-md-1 widget-area">
                        <div class="widget clearfix usful-links">
                            <h3 class="widget-title">Quick Links</h3>
                            <ul>
                                <li><a href="<?php echo e(route('aboutus')); ?>">About Us</a></li>
                                <li><a href="<?php echo e(route('inventorylist')); ?>">Our Inventory</a></li>
                                <li><a href="<?php echo e(route('contactus')); ?>">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-3 first-footer py-5">
                        <div class="row m-0 p-0">
                            <div class="col-md-12">
                                <div class="links footer-contact-links">
                                    <div class="footer-contact-links-wrapper row">
                                        <div class="col-12 footer-contact-link-wrapper mb-3">
                                            <div class="image-wrapper footer-contact-link-icon">
                                                <div class="icon-footer"> <i class="flaticon-phone-call"></i> </div>
                                            </div>
                                            <div class="footer-contact-link-content">
                                                <h6>Call us</h6>
                                                <p><?php echo e($contact_info->phone_no); ?></p>
                                            </div>
                                        </div>
                                        <!-- <div class="footer-contact-links-divider"></div> -->
                                        <div class="col-12 footer-contact-link-wrapper mb-3">
                                            <div class="image-wrapper footer-contact-link-icon">
                                                <div class="icon-footer"> <i class="omfi-envelope"></i> </div>
                                            </div>
                                            <div class="footer-contact-link-content">
                                                <h6>Write to us</h6>
                                                <p><?php echo e($contact_info->email); ?></p>
                                            </div>
                                        </div>
                                        <!-- <div class="footer-contact-links-divider"></div> -->
                                        <div class="col-12 footer-contact-link-wrapper">
                                            <div class="image-wrapper footer-contact-link-icon">
                                                <div class="icon-footer"> <i class="omfi-location"></i> </div>
                                            </div>
                                            <div class="footer-contact-link-content">
                                                <h6>Address</h6>
                                                <p><?php echo e($contact_info->address); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bottom footer -->
            <div class="bottom-footer-text">
                <div class="row copyright">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy;<?php echo date('Y');?> GuruMotors. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
   <!-- jQuery -->
   
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-migrate-3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/modernizr-2.6.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.isotope.v3.0.2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrollIt.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.stellar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/YouTubePopUp.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vegas.slider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>

    <script>
            let logo_light = "<?php echo e(asset('assets/img/logo-light.png')); ?>";
            let logo_dark = "<?php echo e(asset('assets/img/logo-dark.png')); ?>";
    </script>

    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <!-- Vegas Background Slideshow (vegas.slider kenburns) -->
    <script>
        $(document).ready(function() {
            
            $('#kenburnsSliderContainer').vegas({
                slides: [{
                    src: "<?php echo e(asset('assets/img/slider/1.jpg')); ?>"
                }, {
                    src: "<?php echo e(asset('assets/img/slider/3.jpg')); ?>"
                }, {
                    src: "<?php echo e(asset('assets/img/slider/11.jpg')); ?>"
                }],
                overlay: true,
                transition: 'fade2',
                animation: 'kenburnsUpRight',
                transitionDuration: 1000,
                delay: 10000,
                animationDuration: 20000
            });
        });
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\cars_by_guru\resources\views/layouts/app.blade.php ENDPATH**/ ?>